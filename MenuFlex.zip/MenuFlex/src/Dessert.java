public class Dessert extends MenuItem {
    public Dessert(String name, double price) {
        super(name, price);
    }

    @Override
    public void print() {
        System.out.println(name + " - " + price + "$");
        if (!description.isEmpty()) {
            System.out.println("Descripción: " + description);
        }
    }
}
