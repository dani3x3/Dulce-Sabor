public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();

        MainCourse salmon = new MainCourse("Filete de Salmón", 18.99);
        salmon.setDescription("Delicioso filete de salmón fresco.");
        salmon.addExtraOption("Agregar doble porción de queso");
        salmon.addExtraOption("Agregar arroz");

        SideDish rice = new SideDish("Arroz", 3.99);
        rice.setDescription("Arroz blanco suave.");
        rice.addExtraOption("Agregar vegetales");

        Dessert iceCream = new Dessert("Helado de Vainilla", 4.99);
        iceCream.setDescription("Helado cremoso de vainilla.");

        menu.addItem(salmon);
        menu.addItem(rice);
        menu.addItem(iceCream);

        menu.printMenu();
    }
}
