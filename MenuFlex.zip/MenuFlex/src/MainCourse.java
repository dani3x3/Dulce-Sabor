import java.util.ArrayList;
import java.util.List;

public class MainCourse extends MenuItem {
    private List<String> extraOptions = new ArrayList<>();

    public MainCourse(String name, double price) {
        super(name, price);
    }

    public void addExtraOption(String option) {
        extraOptions.add(option);
    }

    @Override
    public void print() {
        System.out.println(name + " - " + price + "$");
        if (!description.isEmpty()) {
            System.out.println("Descripción: " + description);
        }
        if (!extraOptions.isEmpty()) {
            System.out.println("Opciones Extras:");
            for (String option : extraOptions) {
                System.out.println("  - " + option);
            }
        }
    }
}
