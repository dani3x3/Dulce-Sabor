import java.util.Scanner;

public class MenuFlex {
    private static Menu menu = new Menu();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            showOptions();
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addMainCourse();
                    break;
                case 2:
                    addSideDish();
                    break;
                case 3:
                    addDessert();
                    break;
                case 4:
                    menu.printMenu();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }

    private static void showOptions() {
        System.out.println("Elija una opción:");
        System.out.println("1. Agregar Plato Principal");
        System.out.println("2. Agregar Acompañamiento");
        System.out.println("3. Agregar Postre");
        System.out.println("4. Imprimir Menú");
        System.out.println("5. Salir");
        System.out.print("Opción: ");
    }

    private static void addMainCourse() {
        System.out.print("Nombre del Plato Principal: ");
        String name = scanner.nextLine();
        System.out.print("Precio: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        MainCourse mainCourse = new MainCourse(name, price);

        System.out.print("Descripción (opcional): ");
        String description = scanner.nextLine();
        if (!description.isEmpty()) {
            mainCourse.setDescription(description);
        }

        while (true) {
            System.out.print("Agregar opción extra (dejar vacío para terminar): ");
            String option = scanner.nextLine();
            if (option.isEmpty()) {
                break;
            }
            mainCourse.addExtraOption(option);
        }

        menu.addItem(mainCourse);
    }

    private static void addSideDish() {
        System.out.print("Nombre del Acompañamiento: ");
        String name = scanner.nextLine();
        System.out.print("Precio: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        SideDish sideDish = new SideDish(name, price);

        System.out.print("Descripción (opcional): ");
        String description = scanner.nextLine();
        if (!description.isEmpty()) {
            sideDish.setDescription(description);
        }

        while (true) {
            System.out.print("Agregar opción extra (dejar vacío para terminar): ");
            String option = scanner.nextLine();
            if (option.isEmpty()) {
                break;
            }
            sideDish.addExtraOption(option);
        }

        menu.addItem(sideDish);
    }

    private static void addDessert() {
        System.out.print("Nombre del Postre: ");
        String name = scanner.nextLine();
        System.out.print("Precio: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        Dessert dessert = new Dessert(name, price);

        System.out.print("Descripción (opcional): ");
        String description = scanner.nextLine();
        if (!description.isEmpty()) {
            dessert.setDescription(description);
        }

        menu.addItem(dessert);
    }
}
